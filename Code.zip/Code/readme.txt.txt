The name of the program��EEMD-SVD-ELM.
The title of the manuscript��An Automatic Recognition Model of Microseismic Signals Based on EEMD-SVD and ELM.
Author name:Jinyong Zhang, Nuwen Xu, Ruochen Jiang, Biao Li.
Email address: xunuwen@scu.edu.cn (Nuwen Xu).