%% Decompose microseimic signals by EEMD-SVD-ELM
%% I.import the data after normalization
load('data.mat');
%% II.Initialization parameter
% number of events
NumSei=2;
NumBla=2;
NumGroup=NumSei+NumBla;
%parameters of EEMD
Nstd=0.2;
NR=100;
% set the number of training sets and test sets
NumTrain=1;
NumTest=1;
LengthAxis=NumTrain+NumTest+1;
% set the number of hidden layer neurons
NumNode=16;
%% III.We use EEMD-SVD to extract the characteristic values of signals.
sigvalue_data=[];
for i=1:NumGroup
    datum=data(:,i);
    %We use the eemd to decompose each signal.
    IMF=eemd(datum,Nstd,NR,5000);
    IMF2=IMF';
    %calculate correlation coefficients and select the components
    cor=cori(datum,IMF2);
    cor2=cor';
    newIMF=IMF2(:,2:8);
    %calculate the sigular value 
    sigvalue=svd(newIMF);
    sigvalue_data=[sigvalue_data,sigvalue];
end
sigvalue_weizhen=sigvalue_data(:,1:NumSei);
sigvalue_baopo=sigvalue_data(:,NumSei+1:NumGroup);
%% IV.build the ELM neural network 
%% Mark the category of the signal
tic
u=ones(NumSei,1);
u2=2*ones(2,1);
weizhen_data=[u,sigvalue_weizhen'];
baopo_data=[u2,sigvalue_baopo'];
%% Randomly select 2 groups as the training set;and select 2 groups as the test set 
n=randperm(NumSei);
m=randperm(NumBla);
% training sets
input_train1=weizhen_data(n(1:NumTrain),2:8)';
input_train2=baopo_data(m(1:NumTest),2:8)'; 
input_train=[input_train1,input_train2];
output_train1=weizhen_data(n(1:NumTrain),1)';
output_train2=baopo_data(m(1:NumTest),1)'; 
output_train=[output_train1,output_train2];
%test sets
input_test1=weizhen_data(n(NumTrain+1:NumSei),2:8)';
input_test2=baopo_data(m(NumTest+1:NumBla),2:8)';
input_test=[input_test1,input_test2];
output_test1=weizhen_data(n(NumTrain+1:NumSei),1)';
output_test2=baopo_data(m(NumTest+1:NumBla),1)'; 
output_test=[output_test1,output_test2];
%normalization
[inputn,inputps]=mapminmax(input_train);
%[outputn,outputps]=mapminmax(output_train);
inputn_test=mapminmax('apply',input_test,inputps);

%% training
[IW,B,LW,TF,TYPE] = elmtrain(inputn,output_train,NumNode,'sig',1);
%%  test
test_simu = elmpredict(inputn_test,IW,B,LW,TF,TYPE);
%% V.result
result = [output_test' test_simu'];
error=test_simu-output_test;
length_class=length(output_test)/2;
sumcorrect=[];
for i=1:2
    error_class=error((i-1)*length_class+1:i*length_class);
    sumcorrect0=length(find((error_class==0)));
    sumcorrect=[sumcorrect,sumcorrect0];
end
disp(['ѵ����ȷ����=' num2str(sumcorrect)])
toc
%figure 
figure
plot(output_test,'*r')
hold on
plot( test_simu','ob')
legend('The actual output','The predicted output')
axis([0 LengthAxis 0 LengthAxis]);





