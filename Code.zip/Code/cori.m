function cor=cori(A,D)
%�����ϵ��
num_column=size(D,2)
cor=[];
for i=1:num_column
    f=corrcoef(A,D(:,i));
    f1=f(2,1);
    cor=[cor,f1];
end